package sistema;

import java.util.Date;

public class Jugador {
	private String nombreJugador;
	private String apellidoJugador;
	private int dniJugador;
	private Date fechaNacimientoJugador;
	private float estatura;
	private float peso;
	private String posicion;
	private int camiseta;
	
	
	
	public Jugador(String nombreJugador, String apellidoJugador, int dniJugador, Date fechaNacimientoJugador,
			float estatura, float peso, String posicion, int camiseta) {
		super();
		this.nombreJugador = nombreJugador;
		this.apellidoJugador = apellidoJugador;
		this.dniJugador = dniJugador;
		this.fechaNacimientoJugador = fechaNacimientoJugador;
		this.estatura = estatura;
		this.peso = peso;
		this.posicion = posicion;
		this.camiseta = camiseta;
	}
	@Override
	public String toString() {
		return "Jugador [nombreJugador=" + nombreJugador + ", apellidoJugador=" + apellidoJugador + ", dniJugador="
				+ dniJugador + ", fechaNacimientoJugador=" + fechaNacimientoJugador + ", estatura=" + estatura
				+ ", peso=" + peso + ", posicion=" + posicion + ", camiseta=" + camiseta + "]";
	}
	public String getNombreJugador() {
		return nombreJugador;
	}
	public void setNombreJugador(String nombreJugador) {
		this.nombreJugador = nombreJugador;
	}
	public String getApellidoJugador() {
		return apellidoJugador;
	}
	public void setApellidoJugador(String apellidoJugador) {
		this.apellidoJugador = apellidoJugador;
	}
	public int getDniJugador() {
		return dniJugador;
	}
	public void setDniJugador(int dniJugador) {
		this.dniJugador = dniJugador;
	}
	public Date getFechaNacimientoJugador() {
		return fechaNacimientoJugador;
	}
	public void setFechaNacimientoJugador(Date fechaNacimientoJugador) {
		this.fechaNacimientoJugador = fechaNacimientoJugador;
	}
	public float getEstatura() {
		return estatura;
	}
	public void setEstatura(float estatura) {
		this.estatura = estatura;
	}
	public float getPeso() {
		return peso;
	}
	public void setPeso(float peso) {
		this.peso = peso;
	}
	public String getPosicion() {
		return posicion;
	}
	public void setPosicion(String posicion) {
		this.posicion = posicion;
	}
	public int getCamiseta() {
		return camiseta;
	}
	public void setCamiseta(int camiseta) {
		this.camiseta = camiseta;
	}
	
	

}
