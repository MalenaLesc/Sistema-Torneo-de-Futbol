package sistema;

import java.util.Date;

public class Entrenador {
	private String nombre;
	private String apellido;
	private int dni;
	private Date fechaNacimiento;
	private String estrategia_favorita;
	
	
	
	public Entrenador(String nombre, String apellido, int dni, Date fechaNacimiento, String estrategia_favorita) {
		super();
		this.nombre = nombre;
		this.apellido = apellido;
		this.dni = dni;
		this.fechaNacimiento = fechaNacimiento;
		this.estrategia_favorita = estrategia_favorita;
	}
	@Override
	public String toString() {
		return "Entrenador [nombre=" + nombre + ", apellido=" + apellido + ", dni=" + dni + ", fechaNacimiento="
				+ fechaNacimiento + ", estrategia_favorita=" + estrategia_favorita + "]";
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getApellido() {
		return apellido;
	}
	public void setApellido(String apellido) {
		this.apellido = apellido;
	}
	public int getDni() {
		return dni;
	}
	public void setDni(int dni) {
		this.dni = dni;
	}
	public Date getFechaNacimiento() {
		return fechaNacimiento;
	}
	public void setFechaNacimiento(Date fechaNacimiento) {
		this.fechaNacimiento = fechaNacimiento;
	}
	public String getEstrategia_favorita() {
		return estrategia_favorita;
	}
	public void setEstrategia_favorita(String estrategia_favorita) {
		this.estrategia_favorita = estrategia_favorita;
	}
	
	
	
	

}
