package sistema;

import java.util.List;

public class Equipo {
	private String nombreEquipo;
	private int codigoId;
	private Entrenador entrenador;
	private List<Jugador> jugadores;
	
	
	
	
	public Equipo(String nombreEquipo, int codigoId, Entrenador entrenador, List<Jugador> jugadores) {
		super();
		this.nombreEquipo = nombreEquipo;
		this.codigoId = codigoId;
		this.entrenador = entrenador;
		this.jugadores = jugadores;
	}
	@Override
	public String toString() {
		return "Equipo [nombreEquipo=" + nombreEquipo + ", codigoId=" + codigoId + ", entrenador=" + entrenador
				+ ", jugadores=" + jugadores + "]";
	}
	public String getNombreEquipo() {
		return nombreEquipo;
	}
	public void setNombreEquipo(String nombreEquipo) {
		this.nombreEquipo = nombreEquipo;
	}
	public int getCodigoId() {
		return codigoId;
	}
	public void setCodigoId(int codigoId) {
		this.codigoId = codigoId;
	}
	public Entrenador getEntrenador() {
		return entrenador;
	}
	public void setEntrenador(Entrenador entrenador) {
		this.entrenador = entrenador;
	}
	public List<Jugador> getJugadores() {
		return jugadores;
	}
	public void setJugadores(List<Jugador> jugadores) {
		this.jugadores = jugadores;
	}
	
	
	

}
